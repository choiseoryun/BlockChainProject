import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css'; // 없다면 제거해도 무방

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
