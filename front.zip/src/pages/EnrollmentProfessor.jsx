import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import CaptchaCheck from '../components/CaptchaCheck';

const DashboardStudent = () => {
  const [account, setAccount] = useState('');
  const [isVerified, setIsVerified] = useState(false);
  const [courses, setCourses] = useState([]);
  const [selectedCourseId, setSelectedCourseId] = useState('');
  const [status, setStatus] = useState('');
  const navigate = useNavigate();

  const connectWallet = async () => {
    if (window.ethereum) {
      try {
        const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
        setAccount(accounts[0]);
      } catch (error) {
        console.error('지갑 연결 실패:', error);
      }
    } else {
      alert('MetaMask를 설치해주세요.');
    }
  };

  useEffect(() => {
  // 과목 리스트를 항상 불러옴 (지갑 연결 여부와 무관)
  const fetchCourses = async () => {
    try {
      const res = await fetch('/enrollment/course/professor');
      const data = await res.json();
      if (data.success) {
        setCourses(data.courses);
        if (data.courses.length > 0) {
          setSelectedCourseId(data.courses[0].course_id);
        }
      } else {
        setStatus('수강 과목 로드 실패');
      }
    } catch (err) {
      console.error(err);
      setStatus('서버 오류');
    }
  };
  fetchCourses();
}, []);
useEffect(() => {
  // 지갑 연결은 따로
  connectWallet();
}, []);
  const goToEnrollmentPage = () => {
    navigate('/enrollment/student');
  };

  const submitAttendance = async () => {
    if (!selectedCourseId) {
      setStatus('과목을 선택하세요.');
      return;
    }

    try {
      const res = await fetch(`/attendance/submit/${selectedCourseId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ account }),
      });

      if (res.ok) {
        setStatus('출석이 제출되었습니다!');
      } else {
        setStatus('출석 제출 실패');
      }
    } catch (err) {
      console.error(err);
      setStatus('서버 오류');
    }
  };

  return (
    <div className="container p-4 max-w-2xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">학생 대시보드</h2>
      <p className="mb-4">지갑 주소: {account || '연결되지 않음'}</p>

      <div className="mt-4">
        <label className="block mb-1">수강 과목</label>
        <select
          value={selectedCourseId}
          onChange={(e) => setSelectedCourseId(e.target.value)}
          className="block border border-gray-300 rounded p-2 mb-4 w-full"
        >
          {courses.length > 0 ? (
            courses.map((course) => (
              <option key={course.course_id} value={course.course_id}>
                {course.course_name} ({course.semester})
              </option>
            ))
          ) : (
            <option disabled>수강 과목이 없습니다</option>
          )}
        </select>

        <button
          onClick={goToEnrollmentPage}
          className="bg-green-600 text-white py-2 px-4 rounded hover:bg-green-700 transition duration-300"
        >
          수강신청 페이지로 이동
        </button>
      </div>

      {/* ✅ 여기서 CaptchaCheck는 과목 선택 이후에 */}
      {account && (
        <div className="mt-4">
          <CaptchaCheck onVerified={() => setIsVerified(true)} />
        </div>
      )}

      {/* ✅ 캡차 인증 후 출석 제출 버튼 표시 */}
      {isVerified && (
        <div className="mt-4">
          <button
            onClick={submitAttendance}
            className="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700 transition duration-300"
          >
            출석 제출
          </button>
        </div>
      )}

      <p className="mt-4 text-red-500">{status}</p>
    </div>
  );
};

export default DashboardStudent;
